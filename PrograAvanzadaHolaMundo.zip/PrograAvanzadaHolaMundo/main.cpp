#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
  cout<<"HOLA MUNDO C++ Curso Programaci\'on Avanzada"<<endl;
  system("PAUSE");
  return EXIT_SUCCESS;
}
