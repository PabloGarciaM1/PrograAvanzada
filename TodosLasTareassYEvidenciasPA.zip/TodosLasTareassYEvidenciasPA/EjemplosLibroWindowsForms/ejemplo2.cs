﻿[assembly: System.Reflection.AssemblyVersion("1.3")]
namespace MyNamespace
{
    using System;
    using System.Drawing;
    using System.Windows.Forms;
    public class MyForm : System.Windows.Forms.Form
    {
        Button btnLoad;
        PictureBox pboxPhoto;
        public MyForm()
        {
            this.Text = "Hello Form 1.3";
            // Create and configure the Button
            btnLoad = new Button();
            btnLoad.Text = "&Load";
            btnLoad.Left = 10;
            btnLoad.Top = 10;
            btnLoad.Click += new System.EventHandler(this.OnLoadClick);
            // Create and configure the PictureBox
            pboxPhoto = new PictureBox();
            pboxPhoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            pboxPhoto.Width = this.Width / 3;
            pboxPhoto.Height = this.Height / 3;
            pboxPhoto.Left = (this.Width - pboxPhoto.Width) / 2;
            pboxPhoto.Top = (this.Height - pboxPhoto.Height) / 2;
            pboxPhoto.SizeMode = PictureBoxSizeMode.StretchImage;
            // Add our new controls to the Form
            this.Controls.Add(btnLoad);
            this.Controls.Add(pboxPhoto);
        }
        private void OnLoadClick(object sender, System.EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Photo";
            dlg.Filter = "jpg files (*.jpg)|*.jpg|All files (*.*)|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                pboxPhoto.Image = new Bitmap(dlg.OpenFile());
            }
            dlg.Dispose();
        }
        public static void Main()
        {
            Application.Run(new MyForm());
        }
    }
}